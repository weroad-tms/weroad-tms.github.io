// 위펀오피스 화면에 위로드 부팅 스크립트(boot.js)를 페이지 쪽에 넣는다. 채널(정식/개발)은 팝업에서 고름.
(function () {
  if (window.top !== window) return;   // iframe 안에서는 실행 안 함
  chrome.storage.local.get({ ch: 'stable' }, function (o) {
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('boot.js');
    s.dataset.ch = o.ch === 'dev' ? 'dev' : 'stable';
    s.onload = function () { s.remove(); };
    (document.head || document.documentElement).appendChild(s);
  });
  // 팝업의 [위로드 열기] → 페이지에 신호
  chrome.runtime.onMessage.addListener(function (m) { if (m && m.open) window.postMessage({ __wr_ext: 'open' }, location.origin); });
})();
