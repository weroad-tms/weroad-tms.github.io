// 위로드 확장프로그램 부팅 — 북마크와 같은 순서(로그인돼 있으면 코드 불러와 붙이기, 아니면 로그인 화면)
// 차이: 페이지를 열 때마다 자동으로 붙고, 창은 저절로 열지 않음(오른쪽 아래 위로드 버튼으로 열기).
(function () {
  'use strict';
  var me = document.currentScript, C = (me && me.dataset.ch) || 'stable';
  var U = 'https://evyxvhqerfuqmzwjhkgz.supabase.co', K = 'sb_publishable_DNESzKpu1WcxT9sx15D5fw_jVan14DH';
  if (window.__WR_EXT__) return; window.__WR_EXT__ = 1;
  function op() { try { var h = document.getElementById('wf-dcal-host'); if (h && h.shadowRoot) { var b = h.shadowRoot.querySelector('.launch'); if (b) b.click(); } } catch (e) { /* noop */ } }
  function rpc(f, b) { return fetch(U + '/rest/v1/rpc/' + f, { method: 'POST', credentials: 'omit', headers: { apikey: K, 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j && j.message || r.status); return j; }); }); }
  function inj(t) { var s = document.createElement('script'); s.textContent = t; document.documentElement.appendChild(s); s.remove(); }
  function tok() { try { var a = JSON.parse(localStorage.getItem('wr-auth') || 'null'); return a && a.token || ''; } catch (e) { return ''; } }
  function shell() { return rpc('app_code_get', { p_token: '', p_channel: 'shell' }).then(inj).catch(function (e) { alert('위로드를 불러오지 못했습니다: ' + (e && e.message || e)); }); }
  // 북마크와 같은 이름 — 로그인 화면(shell)이 로그인 후 이걸 부름
  window.__WR_LOAD__ = function () { return rpc('app_code_get', { p_token: tok(), p_channel: C }).then(function (t) { window.__WEROAD_CHANNEL__ = C; inj(t); setTimeout(op, 300); }); };
  var btn = null;
  function button() {   // 로그인 전: 오른쪽 아래 작은 위로드 버튼
    if (btn || window.__WF_DCAL__) return;
    btn = document.createElement('button'); btn.type = 'button'; btn.textContent = '위로드';
    btn.title = '위로드 로그인';
    btn.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483000;border:0;border-radius:14px;padding:11px 16px;background:#3E6AF2;color:#fff;font:800 14px/1 "Malgun Gothic",system-ui,sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.25);cursor:pointer';
    btn.onclick = start;
    document.documentElement.appendChild(btn);
  }
  function start() { if (btn) { btn.remove(); btn = null; } if (window.__WF_DCAL__) { op(); return; } (tok() ? window.__WR_LOAD__() : Promise.reject()).catch(shell); }
  window.addEventListener('message', function (e) { if (e.source === window && e.data && e.data.__wr_ext === 'open') start(); });
  if (!tok()) { button(); return; }
  window.__WR_QUIET__ = true;   // 자동으로 붙일 때는 창을 열지 않음
  rpc('app_code_get', { p_token: tok(), p_channel: C }).then(function (t) { window.__WEROAD_CHANNEL__ = C; inj(t); })
    .catch(function () { window.__WR_QUIET__ = false; button(); });
})();
