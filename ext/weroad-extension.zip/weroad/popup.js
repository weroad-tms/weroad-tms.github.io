var dev = document.getElementById('dev'), m = document.getElementById('m');
chrome.storage.local.get({ ch: 'stable' }, function (o) { dev.checked = o.ch === 'dev'; });
dev.onchange = function () { chrome.storage.local.set({ ch: dev.checked ? 'dev' : 'stable' }, function () { m.textContent = '바꿨어요. 위펀오피스를 새로고침 하면 적용돼요.'; }); };
document.getElementById('open').onclick = function () {
  chrome.tabs.query({ url: ['https://office.wefun.kr/*', 'http://office.wefun.kr/*'] }, function (tabs) {
    var t = (tabs || []).filter(function (x) { return x.active; })[0] || (tabs || [])[0];
    if (t) { chrome.tabs.update(t.id, { active: true }); chrome.windows.update(t.windowId, { focused: true }); chrome.tabs.sendMessage(t.id, { open: true }); window.close(); }
    else chrome.tabs.create({ url: 'https://office.wefun.kr/' });
  });
};
